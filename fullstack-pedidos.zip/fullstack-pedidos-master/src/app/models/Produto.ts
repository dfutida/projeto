/*
 * Classe: Produto
 */
export class Produto {
  _id: string;
  id: string;
  nome: string;
  preco: string;
  multiplo: string;
}
