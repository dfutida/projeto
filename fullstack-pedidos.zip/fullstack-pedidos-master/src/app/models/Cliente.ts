/*
 * Classe: Cliente
 */
export class Cliente {
  _id: string;
  id: string;
  nome: string;
}
