export const environment = {
  production: true,
  apiUrl: {
    pedidos: 'https://fullstack-pedidos.herokuapp.com/pedidos',
    produtos: 'https://fullstack-pedidos.herokuapp.com/produtos',
    clientes: 'https://fullstack-pedidos.herokuapp.com/clientes'
  }
};
